package team.sqlww.OAsystem.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.dao.LeaveDao;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.Leave;
import team.sqlww.OAsystem.model.User;

public class LeaveDaoImpl extends BaseDao implements LeaveDao{

	@Override
	public boolean delLeave(int x) {
		String sql= "delete from Leave where L_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean addLeave(Leave x) {
		String sql="insert into oa_Leave"+"(message,L_date,L_status,User_ID)values(?,?,?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1,x.getLeave_message());
			pst.setString(2, x.getLeave_date());
			pst.setInt(3, x.getLeave_status());
			pst.setInt(4, x.getUser_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateLeave(Leave x) {
		
		String sql="update oa_Leave set message=?,L_date=?,L_status=?,User_ID=? where L_id=? ;";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1,x.getLeave_message());
			pst.setString(2, x.getLeave_date());
			pst.setInt(3, x.getLeave_status());
			pst.setInt(4, x.getUser_id());
			pst.setInt(5, x.getLeave_id());
			pst.executeUpdate();
			return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}




	@Override
	public ArrayList<Leave> getLeavebyid(int x) {
		ArrayList<Leave> list=new ArrayList();
		String sql="SELECT * from oa_Leave where user_id=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 Leave s=new Leave();
				 s.setLeave_id(ret.getInt(1));
				 s.setLeave_message(ret.getString(2));
				 s.setLeave_date(ret.getString(3));
				 s.setLeave_status(ret.getInt(4));
				 s.setUser_id(ret.getInt(5));

				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public ArrayList<Leave> getLeaveNotCheck() {
		ArrayList<Leave> list=new ArrayList();
		String sql="SELECT * from oa_Leave where L_status=0;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 Leave s=new Leave();
				 s.setLeave_id(ret.getInt(1));
				 s.setLeave_message(ret.getString(2));
				 s.setLeave_date(ret.getString(3));
				 s.setLeave_status(ret.getInt(4));
				 s.setUser_id(ret.getInt(5));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public Leave getLeavebyL_id(int x) {
		String sql="SELECT * from oa_Leave where L_id=?;";
		Leave s=new Leave();
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();//ע��Ҫ�Ƚ�x����pst��ȡִ�н��
			 while (ret.next()) {
				 s.setLeave_id(ret.getInt(1));
				 s.setLeave_message(ret.getString(2));
				 s.setLeave_date(ret.getString(3));
				 s.setLeave_status(ret.getInt(4));
				 s.setUser_id(ret.getInt(5));
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}

	@Override
	public boolean delLeavebyid(int x) {
		String sql= "delete from oa_Leave where User_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

}
