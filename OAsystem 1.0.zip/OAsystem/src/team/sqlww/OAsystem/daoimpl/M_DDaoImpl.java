package team.sqlww.OAsystem.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.dao.M_DDao;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.M_D;

public class M_DDaoImpl  extends BaseDao implements M_DDao{

	@Override
	public boolean delM_D(int x) {
		String sql= "delete from MD where Department_D_ID=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean addM_D(M_D x) {
		String sql="insert into MD"+"(Department_D_ID,user_id)values(?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setInt(1, x.getDepartment_id());
			pst.setInt(2, x.getUser_id());		
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateM_D(M_D x) {
		String sql="update MD set Department_D_ID=?, user_id=? where Department_D_ID=? ;";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			pst.setInt(1, x.getDepartment_id());
			pst.setInt(2, x.getUser_id());
			pst.setInt(3, x.getDepartment_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public M_D getM_Dbyid(int id) {
		M_D s=new M_D();
		String sql="SELECT * from MD where User_id=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
			
		{
			pst.setInt(1, id);
			ResultSet ret=pst.executeQuery();
			while (ret.next()) {
				 s.setDepartment_id(ret.getInt(1));
				 s.setUser_id(ret.getInt(2));
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
		
	
	}

	@Override
	public M_D getM_Dbyd_id(int x) {
		M_D s=new M_D();
		String sql="SELECT * from MD where Department_D_ID=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
			
		{
			pst.setInt(1, x);
			ResultSet ret=pst.executeQuery();
			while (ret.next()) {
				 s.setDepartment_id(ret.getInt(1));
				 s.setUser_id(ret.getInt(2));
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}

}
