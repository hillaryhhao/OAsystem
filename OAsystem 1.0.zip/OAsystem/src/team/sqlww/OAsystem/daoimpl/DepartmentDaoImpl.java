package team.sqlww.OAsystem.daoimpl;
import team.sqlww.OAsystem.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import team.sqlww.OAsystem.daoimpl.BaseDao;
import team.sqlww.OAsystem.dao.*;
import team.sqlww.OAsystem.model.*;

public class DepartmentDaoImpl  extends BaseDao implements DepartmentDao{
	

	public boolean addDepartment(Department x){
		
		String sql="insert into department"+"(d_name,d_number,d_achievement)values(?,?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1, x.getDepartment_name());
			pst.setString(2, x.getDepartment_numberofemployee());
			pst.setString(3, x.getDepartment_achievement());
		
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
//���Ӳ��Ų���
	public boolean delDepartment(int x){
		String sql= "delete from department where d_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
//ɾ�����Ų���

	public boolean updateDepartment(Department x){
		
		String sql="update department set d_name=?, d_number=?,d_achievement=? where d_id=? ;";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1, x.getDepartment_name());
			pst.setString(2, x.getDepartment_numberofemployee());
			pst.setString(3, x.getDepartment_achievement());
			pst.setInt(4, x.getDepartment_id());
		
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
//�޸Ĳ�����Ϣ
	public ArrayList<Department> getAllDepartment(){
		ArrayList<Department> list=new ArrayList();
		String sql="SELECT * from department;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); 
			ResultSet ret=pst.executeQuery())
		{
			 while (ret.next()) {
				 Department s=new Department();
				 s.setDepartment_id(ret.getInt(1));
				 s.setDepartment_name(ret.getString(2));
				 s.setDepartment_numberofemployee(ret.getString(3));
				 s.setDepartment_achievement(ret.getString(4));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}
//����ȫ������
	@Override
	public Department getDepartmentbyD_id(int x) {
		String sql="SELECT * from Department where d_id=?;";
		Department s=new Department();
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();//ע��Ҫ�Ƚ�x����pst��ȡִ�н��
			 while (ret.next()) {
				 s.setDepartment_id(ret.getInt(1));
				 s.setDepartment_name(ret.getString(2));
				 s.setDepartment_numberofemployee(ret.getString(3));
				 s.setDepartment_achievement(ret.getString(4));
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}
	
}
