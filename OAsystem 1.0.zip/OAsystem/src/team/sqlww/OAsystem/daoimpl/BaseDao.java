package team.sqlww.OAsystem.daoimpl;


import java.sql.Connection;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class BaseDao {  
	public   DataSource datasource;
    public BaseDao(){
   	 try {
			Context context=new InitialContext();
			datasource=(DataSource)context.lookup("java:comp/env/jdbc/oasystem");
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   	 
    }
    
    public Connection getconnection() throws Exception{
   	 return datasource.getConnection();
    }
}