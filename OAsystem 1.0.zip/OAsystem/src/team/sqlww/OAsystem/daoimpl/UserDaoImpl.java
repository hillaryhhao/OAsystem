package team.sqlww.OAsystem.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.dao.UserDao;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.User;

public class UserDaoImpl extends BaseDao implements UserDao{

	@Override
	public boolean delUser(int x) {
		String sql= "delete from user where id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean addUser(User x) {
		String sql="insert into User"+"(name,password,sex,telephone,address,age,status,position,Department_d_id)values(?,?,?,?,?,?,?,?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1, x.getUser_name());
			pst.setString(2, x.getUser_password());
			pst.setString(3, x.getUser_sex());
			pst.setString(4, x.getUser_telephone());
			pst.setString(5, x.getUser_address());
			pst.setString(6, x.getUser_age());
			pst.setInt(7, x.getUser_status());
			pst.setString(8, x.getUser_position());
			pst.setInt(9, x.getDepartment_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 return false;
		}	
	}

	@Override
	public boolean updateUser(User x) {
		String sql="update User set name=?,password=?,sex=?,telephone=?,address=?,age=?,status=?,position=?,Department_d_id=? where id=? ;";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setInt(10, x.getUser_id());
			pst.setString(1, x.getUser_name());
			pst.setString(2, x.getUser_password());
			pst.setString(3, x.getUser_sex());
			pst.setString(4, x.getUser_telephone());
			pst.setString(5, x.getUser_address());
			pst.setString(6, x.getUser_age());
			pst.setInt(7, x.getUser_status());
			pst.setString(8, x.getUser_position());
			pst.setInt(9, x.getDepartment_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			 return false;
		}	
	}

	@Override
	public ArrayList<User> getAllUser(){
		ArrayList<User> list=new ArrayList();
		String sql="SELECT * from User;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); 
			ResultSet ret=pst.executeQuery())
		{
			 while (ret.next()) {
				 User s=new User();
				 s.setUser_id(ret.getInt(1));
				 s.setUser_name(ret.getString(2));
				 s.setUser_password(ret.getString(3));
				 s.setUser_sex(ret.getString(4));
				 s.setUser_telephone(ret.getString(5));
				 s.setUser_address(ret.getString(6));
				 s.setUser_age(ret.getString(7));
				 s.setUser_status(ret.getInt(8));
				 s.setUser_position(ret.getString(9));
				 s.setDepartment_id(ret.getInt(10));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public int checkLogin(int id, String password) {
		int status = 0;
		String sql="SELECT status from User where id=? and password=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
			
		{
			pst.setInt(1, id);
			pst.setString(2, password);
			ResultSet ret=pst.executeQuery();
			if (ret.next()) {
				 
				status=ret.getInt(1);
				
               }//��ʾ����  
			return status;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return 0;
		}
	}

	@Override
	public ArrayList<User> getUserbyD_id(int x) {
		ArrayList<User> list=new ArrayList();
		String sql="SELECT * from User where Department_d_ID=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 User s=new User();
				 s.setUser_id(ret.getInt(1));
				 s.setUser_name(ret.getString(2));
				 s.setUser_password(ret.getString(3));
				 s.setUser_sex(ret.getString(4));
				 s.setUser_telephone(ret.getString(5));
				 s.setUser_address(ret.getString(6));
				 s.setUser_age(ret.getString(7));
				 s.setUser_status(ret.getInt(8));
				 s.setUser_position(ret.getString(9));
				 s.setDepartment_id(ret.getInt(10));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
		
	}

	@Override
	public User getUserbyid(int x) {
		String sql="SELECT * from User where id=?;";
		User s=new User();
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 s.setUser_id(ret.getInt(1));
				 s.setUser_name(ret.getString(2));
				 s.setUser_password(ret.getString(3));
				 s.setUser_sex(ret.getString(4));
				 s.setUser_telephone(ret.getString(5));
				 s.setUser_address(ret.getString(6));
				 s.setUser_age(ret.getString(7));
				 s.setUser_status(ret.getInt(8));
				 s.setUser_position(ret.getString(9));
				 s.setDepartment_id(ret.getInt(10));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}

}
