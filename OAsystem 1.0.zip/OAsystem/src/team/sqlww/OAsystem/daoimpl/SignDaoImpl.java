package team.sqlww.OAsystem.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import team.sqlww.OAsystem.dao.SignDao;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

public class SignDaoImpl extends BaseDao implements SignDao{

	@Override
	public boolean addSign(Sign x) {
		
		String sql="insert into Sign"+"(SignTime,User_ID)values(?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			pst.setString(1, x.getSign_time());
			pst.setInt(2, x.getUser_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public ArrayList<Sign> getSignbyid(int x) {
		ArrayList<Sign> list=new ArrayList();
		String sql="SELECT * from Sign where User_ID=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 Sign s=new Sign();
				 s.setSign_time(ret.getString(1));
				 s.setSign_id(ret.getInt(2));
				 s.setUser_id(ret.getInt(3)); 
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			 
			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public boolean delSignbyid(int x) {
		String sql= "delete from Sign where User_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public ArrayList<Sign> getSignbyD_id(int x) {
		ArrayList<Sign> list=new ArrayList();
		String sql="select * from Sign where User_id in (select id from user where department_d_id =?);";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 Sign s=new Sign();
				 s.setSign_time(ret.getString(1));
				 s.setSign_id(ret.getInt(2));
				 s.setUser_id(ret.getInt(3)); 
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			 
			 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

}
