package team.sqlww.OAsystem.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import team.sqlww.OAsystem.dao.ScheduleDao;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.Schedule;
import team.sqlww.OAsystem.model.User;

public class ScheduleDaoImpl extends BaseDao implements ScheduleDao{

	@Override
	public boolean delSchedule(int x) {
		String sql= "delete from Schedule where S_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean addSchedule(Schedule x) {
		String sql="insert into Schedule"+"(S_date,S_context,User_ID)values(?,?,?)";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1,x.getSchedule_date());
			pst.setString(2,x.getSchedule_context() );
			pst.setInt(3, x.getUser_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean updateSchedule(Schedule x) {
		String sql="update Schedule set S_date=?, S_context=?,User_id=? where S_id=? ;";
		try (Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql) )
		{
			
			pst.setString(1, x.getSchedule_date());
			pst.setString(2, x.getSchedule_context());
			pst.setInt(3, x.getUser_id());
			pst.setInt(4, x.getSchedule_id());
			pst.executeUpdate();
			 return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean delSchedulebyUser_id(int x) {
		String sql= "delete from Schedule where User_id=?;";
		try(Connection con=datasource.getConnection();
				PreparedStatement pst=con.prepareStatement(sql)) 
		{
			 pst.setInt(1, x);
			 pst.executeUpdate();
			 return true;
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public ArrayList<Schedule> getSchedulebyid(int x) {
		ArrayList<Schedule> list=new ArrayList();
		String sql="SELECT * from Schedule where User_ID=?;";
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{	
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();
			 while (ret.next()) {
				 Schedule s=new Schedule();
				 s.setSchedule_date(ret.getString(1));
				 s.setSchedule_context(ret.getString(2));
				 s.setSchedule_id(ret.getInt(3));
				 s.setUser_id(ret.getInt(4));
				 //�����ݴ������в�ѹ��ArrayList�н��б���
	             list.add(s);
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}

	@Override
	public Schedule getSchedulebyS_id(int x) {
		String sql="SELECT * from Schedule where S_id=?;";
		Schedule s=new Schedule();
		try (
			Connection con= datasource.getConnection();
			PreparedStatement pst=con.prepareStatement(sql); )
		{
			 pst.setInt(1, x);
			 ResultSet ret=pst.executeQuery();//ע��Ҫ�Ƚ�x����pst��ȡִ�н��
			 while (ret.next()) {
				 s.setSchedule_date(ret.getString(1));
				 s.setSchedule_context(ret.getString(2));
				 s.setSchedule_id(ret.getInt(3));
				 s.setUser_id(ret.getInt(4));
               }//��ʾ����  
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return s;
	}

}
