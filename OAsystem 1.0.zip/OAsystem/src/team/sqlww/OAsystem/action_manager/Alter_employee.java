package team.sqlww.OAsystem.action_manager;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Alter_employee
 */
@WebServlet("/Alter_employee")
public class Alter_employee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter_employee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int uid= Integer.valueOf((String) request.getSession().getAttribute("s_id")) ;
		String name=request.getParameter("name");
		String sex=request.getParameter("sex");
		String add=request.getParameter("add");
		String tel=request.getParameter("tel");
		String age=request.getParameter("age");
		
		User ou=UserDaoFactory.getInstance().getUserbyid(uid);

		ou.setUser_name(name);
		ou.setUser_sex(sex);
		ou.setUser_address(add);
		ou.setUser_telephone(tel);
		ou.setUser_age(age);

		UserDaoFactory.getInstance().updateUser(ou);
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_employee");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
