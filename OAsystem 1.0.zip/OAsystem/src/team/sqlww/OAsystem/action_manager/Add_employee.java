package team.sqlww.OAsystem.action_manager;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Add_employee
 */
@WebServlet("/Add_employee")
public class Add_employee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add_employee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		String name=request.getParameter("name");
		String password="00";
		String sex=request.getParameter("sex");
		String telephone=request.getParameter("tel");
		String address=request.getParameter("add");
		String age=request.getParameter("age");
		int status=3;
		String position=null;
		int did=(int) request.getSession().getAttribute("did");
		
		User u=new User();
		u.setUser_id(0);
		u.setUser_name(name);
		u.setUser_password(password);
		u.setUser_sex(sex);
		u.setUser_telephone(telephone);
		u.setUser_address(address);
		u.setUser_age(age);
		u.setUser_status(status);
		u.setUser_position(position);
		u.setDepartment_id(did);
		
		UserDaoFactory.getInstance().addUser(u);//����Ա��
		
		Department d=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(did);
		int i=Integer.valueOf(d.getDepartment_numberofemployee());
		i=(i+1);
		d.setDepartment_numberofemployee(String.valueOf(i));
		DepartmentDaoFactory.getInstance().updateDepartment(d);//����Ա������һ
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_employee");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
