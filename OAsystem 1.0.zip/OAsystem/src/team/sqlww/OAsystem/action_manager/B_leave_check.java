package team.sqlww.OAsystem.action_manager;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Leave;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class B_leave_check
 */
@WebServlet("/B_leave_check")
public class B_leave_check extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public B_leave_check() {
        super();
        // TODO Auto-generated constructor stub
    }
    private Object[][] getselect(ArrayList<Leave> ll){
    	Object [][] ob=new Object[ll.size()][4];
    	for(int i=0;i<ll.size();i++){
    		Leave l=ll.get(i);
    		ob[i][0]=l.getLeave_id();
    		User user=UserDaoFactory.getInstance().getUserbyid(l.getUser_id());
    		ob[i][1]=user.getUser_name();
    		ob[i][2]=l.getLeave_date().substring(0,2)+"��"+l.getLeave_date().substring(2,4)+"��";
    		ob[i][3]=l.getLeave_message();
    	}
		return ob;
    	
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int did=(int) request.getSession().getAttribute("did");
		ArrayList<Leave> llist=LeaveDaoFactory.getInstance().getLeaveNotCheck();
		Object[][] list=getselect(llist);
		
		request.setAttribute("leave_list", list);
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/z_leave_check.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
