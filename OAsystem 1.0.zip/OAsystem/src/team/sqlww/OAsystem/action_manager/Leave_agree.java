package team.sqlww.OAsystem.action_manager;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.model.Leave;

/**
 * Servlet implementation class Leave_agree
 */
@WebServlet("/Leave_agree")
public class Leave_agree extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Leave_agree() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int leave_id=Integer.valueOf( request.getParameter("lid"));
		Leave lq=LeaveDaoFactory.getInstance().getLeavebyL_id(leave_id);
		lq.setLeave_status(1);
		LeaveDaoFactory.getInstance().updateLeave(lq);
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/B_leave_check");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
