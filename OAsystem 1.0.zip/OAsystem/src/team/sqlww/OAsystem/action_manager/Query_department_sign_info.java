package team.sqlww.OAsystem.action_manager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Query_department_sign_info
 */
@WebServlet("/Query_department_sign_info")
public class Query_department_sign_info extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Query_department_sign_info() {
        super();
        // TODO Auto-generated constructor stub
    }

    
	private Map<String,String> getselect(List<User> list){
		Map<String,String> ob = new HashMap();
		for (int i = 0; i < list.size(); i++) {
			User d=list.get(i);
			String a=d.getUser_id()+d.getUser_name();
			
			ArrayList<Sign> slist=SignDaoFactory.getInstance().getSignbyid(d.getUser_id());
			String b="";
			for(int j=0;j<slist.size();j++){
				Sign n=slist.get(j);
				b=b+n.getSign_time().substring(0,2)+"��"+n.getSign_time().substring(2,4)+"��,";
			}
			ob.put(a, b);
			
		}
		return ob;
	}
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int did=(int) request.getSession().getAttribute("did");
		ArrayList<User> ulist=UserDaoFactory.getInstance().getUserbyD_id(did);
		
		Map<String,String> s_signs=getselect(ulist);
		request.setAttribute("s_signs", s_signs);
		RequestDispatcher rd1=getServletContext().getRequestDispatcher("/b_staffs_info.jsp");
		rd1.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
