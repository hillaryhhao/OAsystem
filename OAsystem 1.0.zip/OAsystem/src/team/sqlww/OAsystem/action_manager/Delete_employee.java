package team.sqlww.OAsystem.action_manager;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.daofactory.ScheduleDaoFactory;
import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;

/**
 * Servlet implementation class Delete_employee
 */
@WebServlet("/Delete_employee")
public class Delete_employee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete_employee() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int uid=Integer.valueOf(request.getParameter("s_id"));
		int did=(int) request.getSession().getAttribute("did");
		SignDaoFactory.getInstance().delSignbyid(uid);
		LeaveDaoFactory.getInstance().delLeavebyid(uid);
		ScheduleDaoFactory.getInstance().delSchedulebyUser_id(uid);
		UserDaoFactory.getInstance().delUser(uid);//ɾ��Ա��
		
		Department d=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(did);
		int i=Integer.valueOf(d.getDepartment_numberofemployee());
		i=(i-1);
		d.setDepartment_numberofemployee(String.valueOf(i));
		DepartmentDaoFactory.getInstance().updateDepartment(d);//����Ա������һ
		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_employee");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
