package team.sqlww.OAsystem.daofactory;

import team.sqlww.OAsystem.dao.UserDao;
import team.sqlww.OAsystem.daoimpl.UserDaoImpl;

public class UserDaoFactory {
	public static UserDao getInstance(){
		return new UserDaoImpl();		
	}
}
