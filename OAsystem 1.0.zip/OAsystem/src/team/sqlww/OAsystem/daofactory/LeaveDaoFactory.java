package team.sqlww.OAsystem.daofactory;

import team.sqlww.OAsystem.dao.LeaveDao;
import team.sqlww.OAsystem.daoimpl.LeaveDaoImpl;

public class LeaveDaoFactory {
	public static LeaveDao getInstance(){
		return new LeaveDaoImpl();		
	}
}
