package team.sqlww.OAsystem.daofactory;

import team.sqlww.OAsystem.dao.SignDao;
import team.sqlww.OAsystem.daoimpl.SignDaoImpl;

public class SignDaoFactory {
	public static SignDao getInstance(){
		return new SignDaoImpl();		
	}
}
