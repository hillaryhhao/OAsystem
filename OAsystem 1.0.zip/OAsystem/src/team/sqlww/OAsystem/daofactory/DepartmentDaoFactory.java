package team.sqlww.OAsystem.daofactory;


import team.sqlww.OAsystem.dao.DepartmentDao;
import team.sqlww.OAsystem.daoimpl.DepartmentDaoImpl;



public class DepartmentDaoFactory {
	public static DepartmentDao getInstance(){
		return new DepartmentDaoImpl();		
	}
}
