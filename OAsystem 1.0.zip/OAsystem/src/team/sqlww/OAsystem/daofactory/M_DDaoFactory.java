package team.sqlww.OAsystem.daofactory;

import team.sqlww.OAsystem.dao.M_DDao;
import team.sqlww.OAsystem.daoimpl.M_DDaoImpl;

public class M_DDaoFactory {
	public static M_DDao getInstance(){
		return new M_DDaoImpl();		
	}
}
