package team.sqlww.OAsystem.daofactory;

import team.sqlww.OAsystem.dao.DepartmentDao;
import team.sqlww.OAsystem.dao.ScheduleDao;
import team.sqlww.OAsystem.daoimpl.DepartmentDaoImpl;
import team.sqlww.OAsystem.daoimpl.ScheduleDaoImpl;

public class ScheduleDaoFactory {
	public static ScheduleDao getInstance(){
		return new ScheduleDaoImpl();		
	}
}
