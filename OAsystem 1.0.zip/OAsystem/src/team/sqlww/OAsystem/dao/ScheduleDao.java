package team.sqlww.OAsystem.dao;

import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.model.Schedule;

public interface ScheduleDao {
	public boolean delSchedule(int Schedule);
	public boolean addSchedule(Schedule Schedule);
	public boolean updateSchedule(Schedule M_D);
	public boolean delSchedulebyUser_id(int x);
	public ArrayList<Schedule> getSchedulebyid(int id);
	public Schedule getSchedulebyS_id(int x);
}
