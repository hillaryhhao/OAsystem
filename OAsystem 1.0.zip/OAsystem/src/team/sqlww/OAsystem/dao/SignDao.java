package team.sqlww.OAsystem.dao;

import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.model.Sign;;

public interface SignDao {
	public boolean addSign(Sign Sign);
	public boolean delSignbyid(int x);
	public ArrayList<Sign> getSignbyid(int id);
	public ArrayList<Sign> getSignbyD_id(int x);
}
