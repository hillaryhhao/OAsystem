package team.sqlww.OAsystem.dao;

import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.model.Leave;;

public interface LeaveDao {
	public boolean delLeave(int x);
	public boolean addLeave(Leave x);
	public boolean updateLeave(Leave x);
	public Leave getLeavebyL_id(int x);
	public ArrayList<Leave> getLeavebyid(int x);
	public ArrayList<Leave> getLeaveNotCheck();
	public boolean delLeavebyid(int x);
	
	
}
