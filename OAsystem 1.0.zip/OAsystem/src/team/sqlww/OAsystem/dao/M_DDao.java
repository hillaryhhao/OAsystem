package team.sqlww.OAsystem.dao;

import java.util.List;

import team.sqlww.OAsystem.model.M_D;;

public interface M_DDao {
	public boolean delM_D(int x);
	public boolean addM_D(M_D x);
	public boolean updateM_D(M_D x);
	public M_D getM_Dbyid(int id);
	public M_D getM_Dbyd_id(int x);
}
