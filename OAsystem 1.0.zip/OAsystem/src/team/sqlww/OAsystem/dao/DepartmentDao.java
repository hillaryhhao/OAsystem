package team.sqlww.OAsystem.dao;
import java.util.ArrayList;
import java.util.List;
import team.sqlww.OAsystem.model.Department;



public interface DepartmentDao {
	public boolean delDepartment(int x);
	public boolean addDepartment(Department x);
	public boolean updateDepartment(Department x);
	public ArrayList<Department> getAllDepartment();
	public Department getDepartmentbyD_id(int X);
	

}
