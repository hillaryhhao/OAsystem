package team.sqlww.OAsystem.dao;

import java.util.ArrayList;
import java.util.List;

import team.sqlww.OAsystem.model.User;

public interface UserDao {
	public boolean delUser(int User);
	public boolean addUser(User User);
	public boolean updateUser(User User);
	public ArrayList<User> getAllUser();
	public ArrayList<User> getUserbyD_id(int x);
	public int checkLogin(int id,String password);//����ְλ
	public User getUserbyid(int x); 

}
 