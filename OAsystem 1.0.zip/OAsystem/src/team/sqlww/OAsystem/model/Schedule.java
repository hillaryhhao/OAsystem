package team.sqlww.OAsystem.model;

public class Schedule {
	private int schedule_id;
	private String schedule_date;
	private String schedule_context;
	private int user_id;
	
	public int getSchedule_id() {
		return schedule_id;
	}
	public void setSchedule_id(int schedule_id) {
		this.schedule_id = schedule_id;
	}
	public String getSchedule_date() {
		return schedule_date;
	}
	public void setSchedule_date(String schedule_date) {
		this.schedule_date = schedule_date;
	}
	public String getSchedule_context() {
		return schedule_context;
	}
	public void setSchedule_context(String schedule_context) {
		this.schedule_context = schedule_context;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

}
