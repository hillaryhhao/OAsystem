package team.sqlww.OAsystem.model;

import java.sql.Date;

public class Leave {
	private int leave_id;
	private String leave_message;
	private String leave_date;
	private int leave_status;
	private int user_id;
	
	public int getLeave_id() {
		return leave_id;
	}
	public void setLeave_id(int leave_id) {
		this.leave_id = leave_id;
	}
	public String getLeave_message() {
		return leave_message;
	}
	public void setLeave_message(String leave_message) {
		this.leave_message = leave_message;
	}
	public String getLeave_date() {
		return leave_date;
	}
	public void setLeave_date(String leave_date) {
		this.leave_date = leave_date;
	}
	public int getLeave_status() {
		return leave_status;
	}
	public void setLeave_status(int leave_status) {
		this.leave_status = leave_status;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	
}
