package team.sqlww.OAsystem.model;

public class Department {
	private int department_id;
	private String department_name;
	private String department_numberofemployee;//Ա����
	private String department_achievement;//Ӫҵ��
	
	public int getDepartment_id() {
		return department_id;
	}
	public void setDepartment_id(int department_id) {
		this.department_id = department_id;
	}
	public String getDepartment_name() {
		return department_name;
	}
	public void setDepartment_name(String department_name) {
		this.department_name = department_name;
	}
	public String getDepartment_numberofemployee() {
		return department_numberofemployee;
	}
	public void setDepartment_numberofemployee(String department_numberofemployee) {
		this.department_numberofemployee = department_numberofemployee;
	}
	public String getDepartment_achievement() {
		return department_achievement;
	}
	public void setDepartment_achievement(String department_achievement) {
		this.department_achievement = department_achievement;
	}
}
