package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Managerandemployee_sign
 */
@WebServlet("/Query_sign_info")
public class Query_sign_info extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Query_sign_info() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=(int) request.getSession().getAttribute("id");
		User bu=UserDaoFactory.getInstance().getUserbyid(id);
		
		ArrayList<Sign> list=SignDaoFactory.getInstance().getSignbyid(id);
		ArrayList<String> sl=new ArrayList<String>();
		for(int i=0;i<list.size();i++){
			Sign n=list.get(i);
			String a=n.getSign_time().substring(0, 2)+"��"+n.getSign_time().substring(2, 4)+"��";
			sl.add(a);
			
		}
		request.setAttribute("s_sign_info_list", sl);
		request.setAttribute("u_name",bu.getUser_name());
		
		int flag=3;
		User u=UserDaoFactory.getInstance().getUserbyid(id);
		flag=u.getUser_status();
		if(flag==3){
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/s_sign_info.jsp");
			rd1.forward(request, response);
		}else{
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/b_sign_info.jsp");
			rd1.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
