package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.M_DDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.M_D;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

	    int id=Integer.valueOf(request.getParameter("id"));
	    String password=request.getParameter("password");
	    User user=UserDaoFactory.getInstance().getUserbyid(id);
	    request.getSession().setAttribute("user", user);
	    request.getSession().setAttribute("id", id);
	    
	    Department d=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(user.getDepartment_id());
	    
		request.getSession().setAttribute("did",user.getDepartment_id());
		
		String dep=d.getDepartment_name();		
	    int status=user.getUser_status();
	    String position;
	    if(status==1){
	    	position="�ܾ���";
	    }else if(status==2){
	    	position=dep+"����";
	    }else{
	    	position=dep+"Ա��";
	    }
	    request.getSession().setAttribute("position", position);
	    int gowho=UserDaoFactory.getInstance().checkLogin(id,password);
		switch(gowho){
		case 0:
			String message1="<li>�û������ڣ�</li>";
			request.setAttribute("result", message1);
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/Login.jsp");
			rd1.forward(request, response);
			break;
		case 1:
			
			RequestDispatcher rd3=getServletContext().getRequestDispatcher("/z_manager.jsp");
			rd3.forward(request, response);
			break;
		case 2:
	
			RequestDispatcher rd4=getServletContext().getRequestDispatcher("/b_manager.jsp");
			rd4.forward(request, response);
			break;
		case 3:

			RequestDispatcher rd5=getServletContext().getRequestDispatcher("/s_manager.jsp");
			rd5.forward(request, response);
			break;
			
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
