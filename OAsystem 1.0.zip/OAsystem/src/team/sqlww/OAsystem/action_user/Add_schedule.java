package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.ScheduleDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Schedule;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Add_schedule
 */
@WebServlet("/Add_schedule")
public class Add_schedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Add_schedule() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=(int) request.getSession().getAttribute("id");
		String month=request.getParameter("Month");
		String day=request.getParameter("Day");
		String time=request.getParameter("Time");
		String cont=request.getParameter("leave_reason");
		String date=month+day+time;
		
		ArrayList<Schedule> list;
		list=ScheduleDaoFactory.getInstance().getSchedulebyid(id);
		boolean mark=false;
		for(int i=0;i<list.size();i++){
			Schedule sc=list.get(i);
			if(date.equals(sc.getSchedule_date())){
				mark=true;
				break;
			}
		}
		if(mark){
			String m="ʱ���ͻ��";
			request.setAttribute("result", m);

			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/Query_schedule");
			rd1.forward(request, response);
		}else{
			Schedule cc=new Schedule();
			cc.setSchedule_id(0);
			cc.setSchedule_date(date);
			cc.setSchedule_context(cont);
			cc.setUser_id(id);
			ScheduleDaoFactory.getInstance().addSchedule(cc);
			RequestDispatcher rd2=getServletContext().getRequestDispatcher("/Query_schedule");
			rd2.forward(request, response);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
