package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.ScheduleDaoFactory;
import team.sqlww.OAsystem.model.Schedule;

/**
 * Servlet implementation class Alter_schedule
 */
@WebServlet("/Alter_schedule")
public class Alter_schedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter_schedule() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=(int) request.getSession().getAttribute("id");
		int sc=(int) request.getSession().getAttribute("s_id");
		String month=request.getParameter("Month");
		String day=request.getParameter("Day");
		String time=request.getParameter("Time");
		String cont=request.getParameter("Context");
		String date=month+day+time;
		
		ArrayList<Schedule> list;
		list=ScheduleDaoFactory.getInstance().getSchedulebyid(id);
		boolean mark=false;
		for(int i=0;i<list.size();i++){
			Schedule ss=list.get(i);
			if(date.equals(ss.getSchedule_date())){
				mark=true;
				break;
			}
		}
		
		if(mark){
			String m="ʱ���ͻ��";
			request.setAttribute("result", m);
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/Query_schedule");
			rd1.forward(request, response);
		}else{
			Schedule cc=ScheduleDaoFactory.getInstance().getSchedulebyS_id(sc);
			cc.setSchedule_date(date);
			cc.setSchedule_context(cont);
			ScheduleDaoFactory.getInstance().updateSchedule(cc);
			RequestDispatcher rd2=getServletContext().getRequestDispatcher("/Query_schedule");
			rd2.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
