package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class SignNow
 */
@WebServlet("/u_sign")
public class u_sign extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public u_sign() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	       Calendar calendar=Calendar.getInstance();  
	        /*System.out.println(  
	                "�����ǣ�"+  
	                calendar.get(GregorianCalendar.YEAR)+"��"+  
	                (calendar.get(GregorianCalendar.MONTH)+1)+"��"+  
	                calendar.get(GregorianCalendar.DAY_OF_MONTH)+"��"+  
	                calendar.get(GregorianCalendar.HOUR)+"ʱ"+  
	                calendar.get(GregorianCalendar.MINUTE)+"��"+  
	                calendar.get(GregorianCalendar.SECOND)+"��"  
	                ); */
	        int m=calendar.get(GregorianCalendar.MONTH)+1;//7
	        int d=calendar.get(GregorianCalendar.DAY_OF_MONTH);//5
	        String month,day;
	        if(m<10) {
	        	month="0"+m;
	        
	        }else {
	        	month=String.valueOf(m);
	        }
	        //response.getWriter().print(month);

	        if(d<10) {
	        	day="0"+d;
	        
	        }else {
	        	day=String.valueOf(d);
	        }
	        ///response.getWriter().print(day);
	        
	        String date=month+day;
	        int id=(int) request.getSession().getAttribute("id");
	        User u=UserDaoFactory.getInstance().getUserbyid(id);
	        int st=u.getUser_status();
	        ArrayList<Sign> list=SignDaoFactory.getInstance().getSignbyid(id);
	        boolean mark=false;
	        for(int i=0;i<list.size();i++){
	        	Sign s=new Sign();
	        	s=list.get(i);
	        	if(date.equals(s.getSign_time())){
	        		mark=true;
	        		break;
	        	}
	        }
	        if(mark){
	        	//int f=1;//1�����Ѿ�ǩ��
	        	//request.getSession().setAttribute("ifsign", f);
	        	response.getWriter().append("�Ѿ�ǩ��");
	    		//RequestDispatcher rd1=getServletContext().getRequestDispatcher("/SignNow.jsp");
				//rd1.forward(request, response);
	        }else{
	        	
		        Sign ss=new Sign();
		        ss.setSign_time(date);
		        ss.setUser_id(id);
		        ss.setSign_id(0);
		        SignDaoFactory.getInstance().addSign(ss);
		        if(st==1){
		        	RequestDispatcher rd1=getServletContext().getRequestDispatcher("/z_manage_sign.jsp");
		        	rd1.forward(request, response);
		        }else if(st==2){
		        	RequestDispatcher rd1=getServletContext().getRequestDispatcher("/b_manager.jsp");
		        	rd1.forward(request, response);
		        }else{
		        	RequestDispatcher rd1=getServletContext().getRequestDispatcher("/s_manager.jsp");
		        	rd1.forward(request, response);
		        }
	        }

	        
	        
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
