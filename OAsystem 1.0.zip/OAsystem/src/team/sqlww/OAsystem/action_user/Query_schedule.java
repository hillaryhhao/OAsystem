package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.ScheduleDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Schedule;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Query_schedule
 */
@WebServlet("/Query_schedule")
public class Query_schedule extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Query_schedule() {
        super();
        // TODO Auto-generated constructor stub
    }
	private Object[][] getselect(List<Schedule> list){
		Object[][] s = new Object[list.size()][4];
		for (int i = 0; i < list.size(); i++) {
			Schedule sc = (Schedule) list.get(i);
			s[i][0] = sc.getSchedule_date().substring(0, 1)	;		
			s[i][1] = sc.getSchedule_date().substring(2, 3);
			//��������ҽ��id�õ�ҽ����Ϣ.
			
			s[i][2] =sc.getSchedule_date().substring(4,4);
			s[i][3] =sc.getSchedule_context();
		}
		return s;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=(int) request.getSession().getAttribute("id");
		ArrayList<Schedule> list=new ArrayList<Schedule>();
        int flag;
		
		User u=UserDaoFactory.getInstance().getUserbyid(id);
		flag=u.getUser_status();
		
		list=ScheduleDaoFactory.getInstance().getSchedulebyid(id);
		//Object[][] s_info=getselect(list);
		
		request.setAttribute("s_list", list);
		if(flag==1){
			RequestDispatcher rd2=getServletContext().getRequestDispatcher("/z_schedule.jsp");
			rd2.forward(request, response);
		}else if(flag==2){
			RequestDispatcher rd2=getServletContext().getRequestDispatcher("/b_schedule.jsp");
			rd2.forward(request, response);
		}else{
			RequestDispatcher rd2=getServletContext().getRequestDispatcher("/s_schedule.jsp");
			rd2.forward(request, response);
		}
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	


}
