package team.sqlww.OAsystem.action_user;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.model.Leave;

/**
 * Servlet implementation class employee_leave
 */
@WebServlet("/Employee_leave")
public class Employee_leave extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Employee_leave() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int id =(int) request.getSession().getAttribute("id");
		String month=request.getParameter("Month");
		String day=request.getParameter("Day");
		String cont=request.getParameter("leave_reason");
		String date=month+day;
		
		Leave l=new Leave();
		l.setLeave_date(date);
		l.setLeave_message(cont);
		l.setLeave_id(0);
		l.setLeave_status(0);
		l.setUser_id(id);
		//response.getWriter().println(la.getLeave_date()+la.getLeave_message()+la.getUser_id());
		LeaveDaoFactory.getInstance().addLeave(l);
		//response.getWriter().print("........");

		RequestDispatcher rd5=getServletContext().getRequestDispatcher("/Query_myleave");
		rd5.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
