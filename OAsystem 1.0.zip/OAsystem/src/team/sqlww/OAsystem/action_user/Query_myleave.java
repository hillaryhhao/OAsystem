package team.sqlww.OAsystem.action_user;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.LeaveDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Leave;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Query_myleave
 */
@WebServlet("/Query_myleave")
public class Query_myleave extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Query_myleave() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id=(int) request.getSession().getAttribute("id");
		ArrayList<Leave> list=LeaveDaoFactory.getInstance().getLeavebyid(id);
		request.setAttribute("leave_infos", list);
		

		int flag;
		User u=UserDaoFactory.getInstance().getUserbyid(id);
		flag=u.getUser_status();
		
		if(flag==2){		
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/b_my_leave.jsp");
			rd1.forward(request, response);
		}else{
			RequestDispatcher rd1=getServletContext().getRequestDispatcher("/s_my_leave.jsp");
			rd1.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		doGet(request, response);
	}

}
