package team.sqlww.OAsystem.action_user;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Alter_info
 */
@WebServlet("/Alter_info")
public class Alter_info extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter_info() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int id=(int) request.getSession().getAttribute("id");
		String name=request.getParameter("name");
		String password="0";
		String sex=request.getParameter("sex");
		String add=request.getParameter("add");
		String tel=request.getParameter("tel");
		String age=request.getParameter("age");
		int status;
		String position;
		int d_id=(int) request.getSession().getAttribute("did");
		
		User ou=(User) request.getSession().getAttribute("user_info");
		password=ou.getUser_password();
		status=ou.getUser_status();
		position=ou.getUser_position();
		
		User u=new User();
		u.setUser_id(id);
		u.setUser_name(name);
		u.setUser_password(password);
		u.setUser_sex(sex);
		u.setUser_address(add);
		u.setUser_telephone(tel);
		u.setUser_age(age);
		u.setUser_status(status);
		u.setUser_position(position);
		u.setDepartment_id(d_id);
		
		UserDaoFactory.getInstance().updateUser(u);
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_info");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
