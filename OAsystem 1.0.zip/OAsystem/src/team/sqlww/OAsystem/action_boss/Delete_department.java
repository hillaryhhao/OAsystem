package team.sqlww.OAsystem.action_boss;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.M_DDaoFactory;

/**
 * Servlet implementation class Delete_department
 */
@WebServlet("/Delete_department")
public class Delete_department extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public Delete_department() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		int did= Integer.valueOf(request.getParameter("sid"));

		String num=(String) request.getParameter("num");
		
		int i=Integer.valueOf(num);
		if(i<=0){
			M_DDaoFactory.getInstance().delM_D(did);
			DepartmentDaoFactory.getInstance().delDepartment(did);
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_department");
			rd.forward(request, response);
		}else{
			String m="������Ա";
			request.setAttribute("result", m);
			RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_department");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
