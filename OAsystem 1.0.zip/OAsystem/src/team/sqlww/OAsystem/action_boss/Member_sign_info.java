package team.sqlww.OAsystem.action_boss;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Member_sign_info
 */
@WebServlet("/Member_sign_info")
public class Member_sign_info extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Member_sign_info() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String uname=request.getParameter("staff_name");
		request.setAttribute("u_name", uname);
		int id=Integer.valueOf(uname.substring(0, 6));
		ArrayList<Sign> list=SignDaoFactory.getInstance().getSignbyid(id);
		
		ArrayList<String> sl=new ArrayList<String>();
		for(int i=0;i<list.size();i++){
			Sign n=list.get(i);
			String a=n.getSign_time().substring(0, 2)+"��"+n.getSign_time().substring(2, 4)+"��";
			sl.add(a);
			
		}
		
		request.setAttribute("s_sign_info_list", sl);
		RequestDispatcher rd1=getServletContext().getRequestDispatcher("/z_staff_sign.jsp");
		rd1.forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
