package team.sqlww.OAsystem.action_boss;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.SignDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.Schedule;
import team.sqlww.OAsystem.model.Sign;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Departments_sign_info
 */
@WebServlet("/Department_sign_info")
public class Departments_sign_info extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Departments_sign_info() {
        super();
        // TODO Auto-generated constructor stub
    }

	private Map<String,String> getselect(List<Department> list){
		Map<String ,String> ob = new HashMap<String,String>();
		DecimalFormat    df   = new DecimalFormat("######0.00");//������λС��
		Calendar calendar=Calendar.getInstance(); 
		int day=calendar.get(GregorianCalendar.DAY_OF_MONTH);//5
		for (int i = 0; i < list.size(); i++) {
			Department d=list.get(i);
			ArrayList<Sign> slist=SignDaoFactory.getInstance().getSignbyD_id(d.getDepartment_id());
			double a=0;
			double b=Double.valueOf(d.getDepartment_numberofemployee());
			if(b!=0){
				for(int j=0;j<slist.size();j++){
					a++;
				}
				String v=df.format(a/(day*b));
				ob.put(d.getDepartment_name(), v);
			}else
				ob.put(d.getDepartment_name(), "0");

		}
		return ob;
	}
    private String getstatus(User x){
    	String s;
    	if(x.getUser_status()==2){
    		Department d=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(x.getDepartment_id());    
    		s=d.getDepartment_name()+"����";
    	}else{
    		Department dd=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(x.getDepartment_id());    
    		s=dd.getDepartment_name();
    	}
		return s;
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		ArrayList<Department> dlist=DepartmentDaoFactory.getInstance().getAllDepartment();
		Map<String,String> b_sign=getselect(dlist);
		
		ArrayList<User> ulist=UserDaoFactory.getInstance().getAllUser();		
		ArrayList<String> slist = new ArrayList<String>();
		for(int i=0;i<ulist.size();i++){
			User u=ulist.get(i);
			String a=u.getUser_id()+u.getUser_name()+"("+getstatus(u)+")";
	
			slist.add(a);
		}
		
		request.setAttribute("staff_name_list", slist);
		request.setAttribute("sign_list", b_sign);
		RequestDispatcher rd1=getServletContext().getRequestDispatcher("/z_manage_sign.jsp");
		rd1.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
