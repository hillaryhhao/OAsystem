package team.sqlww.OAsystem.action_boss;

import java.io.IOException;
import java.util.ArrayList;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.User;





/**
 * Servlet implementation class qtoalter
 */
@WebServlet("/b_manager_list")
public class B_manager_list extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public B_manager_list() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int did=Integer.valueOf( request.getParameter("sid"));
		String n=request.getParameter("n");
		String a=request.getParameter("a");
		ArrayList<User> ulist=new ArrayList<User>();
		ulist=UserDaoFactory.getInstance().getUserbyD_id(did);
		
		/*ArrayList<String> userlist = new ArrayList<String>();
		for(int i=0;i<ulist.size();i++){
			User u=ulist.get(i);
			String iname=u.getUser_id()+u.getUser_name();
			userlist.add(iname);
		}*/
		request.setAttribute("b_list", ulist);
		request.setAttribute("did", did);
		request.setAttribute("n", n);
		request.setAttribute("a", a);
	    RequestDispatcher rd=getServletContext().getRequestDispatcher("/z_alter_department.jsp");
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
