package team.sqlww.OAsystem.action_boss;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import team.sqlww.OAsystem.daofactory.DepartmentDaoFactory;
import team.sqlww.OAsystem.daofactory.M_DDaoFactory;
import team.sqlww.OAsystem.daofactory.UserDaoFactory;
import team.sqlww.OAsystem.model.Department;
import team.sqlww.OAsystem.model.M_D;
import team.sqlww.OAsystem.model.User;

/**
 * Servlet implementation class Alter_department
 */
@WebServlet("/Alter_department")
public class Alter_department extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Alter_department() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int did=(int) request.getSession().getAttribute("did");
		String dname=request.getParameter("d_name");
		String dachieve=request.getParameter("d_achievement");

		Department dep=DepartmentDaoFactory.getInstance().getDepartmentbyD_id(did);
		
		dep.setDepartment_name(dname);
		dep.setDepartment_achievement(dachieve);
		DepartmentDaoFactory.getInstance().updateDepartment(dep);//����department��
		

		
		String a=request.getParameter("d_list");//������ֵ

		int managerid=Integer.valueOf(a);
		
		M_D md=new M_D();
		md=M_DDaoFactory.getInstance().getM_Dbyd_id(did);
		int uid=md.getUser_id();
		User u=UserDaoFactory.getInstance().getUserbyid(uid);
		u.setUser_status(3);
		UserDaoFactory.getInstance().updateUser(u);//��Ա��״̬��3
		
		User uu=UserDaoFactory.getInstance().getUserbyid(managerid);
		uu.setUser_status(2);
		UserDaoFactory.getInstance().updateUser(uu);//��Ա��״̬��2��
		

		

		
		RequestDispatcher rd=getServletContext().getRequestDispatcher("/Query_department");
		rd.forward(request, response);		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
